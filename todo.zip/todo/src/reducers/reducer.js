initialState=
    {
    item:'',
    completed:false,
    id:''
}
    
const reducer=(state,action)=>{
    switch(action.type){
        case "new_Todo":
            return [...state, item],
            <div><p></p></div>;
        case "toggle_Todo":
            return state;
        case "filter_Completed_Todos":
            return ;
        default: 
            console.log('default');
    }
}

export {reducer, initialState};