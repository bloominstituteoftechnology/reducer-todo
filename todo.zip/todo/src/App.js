import React from 'react';
import logo from './logo.svg';
import './App.css';
import TodoForm from './components/todoForm';

function App() {
  return (
    <div className="App">
<TodoForm/>
    </div>
  );
}

export default App;
