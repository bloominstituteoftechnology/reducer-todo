import { reducer, initialState } from "../reducers/reducer";

export const Todo=()=>{
    const [state,dispatch]= useReducer(reducer,initialState)

    return(
    <div>{state.item}</div>
    )
}
